
import { ElementData, QuizMode, ComfortLevel } from './types';

export const ELEMENTS_DATA: ElementData[] = [
  // Period 1
  { atomicNumber: 1, symbol: "H", name: "Wasserstoff", atomicMass: "1.008", electronConfiguration: "1s¹", group: 1, period: 1, category: "Nichtmetall", xpos: 1, ypos: 1 },
  { atomicNumber: 2, symbol: "He", name: "Helium", atomicMass: "4.0026", electronConfiguration: "1s²", group: 18, period: 1, category: "Edelgas", xpos: 18, ypos: 1 },
  // Period 2
  { atomicNumber: 3, symbol: "Li", name: "Lithium", atomicMass: "6.94", electronConfiguration: "[He] 2s¹", group: 1, period: 2, category: "Alkalimetall", xpos: 1, ypos: 2 },
  { atomicNumber: 4, symbol: "Be", name: "Beryllium", atomicMass: "9.0122", electronConfiguration: "[He] 2s²", group: 2, period: 2, category: "Erdalkalimetall", xpos: 2, ypos: 2 },
  { atomicNumber: 5, symbol: "B", name: "Bor", atomicMass: "10.81", electronConfiguration: "[He] 2s² 2p¹", group: 13, period: 2, category: "Halbmetall", xpos: 13, ypos: 2 },
  { atomicNumber: 6, symbol: "C", name: "Kohlenstoff", atomicMass: "12.011", electronConfiguration: "[He] 2s² 2p²", group: 14, period: 2, category: "Nichtmetall", xpos: 14, ypos: 2 },
  { atomicNumber: 7, symbol: "N", name: "Stickstoff", atomicMass: "14.007", electronConfiguration: "[He] 2s² 2p³", group: 15, period: 2, category: "Nichtmetall", xpos: 15, ypos: 2 },
  { atomicNumber: 8, symbol: "O", name: "Sauerstoff", atomicMass: "15.999", electronConfiguration: "[He] 2s² 2p⁴", group: 16, period: 2, category: "Nichtmetall", xpos: 16, ypos: 2 },
  { atomicNumber: 9, symbol: "F", name: "Fluor", atomicMass: "18.998", electronConfiguration: "[He] 2s² 2p⁵", group: 17, period: 2, category: "Halogen", xpos: 17, ypos: 2 },
  { atomicNumber: 10, symbol: "Ne", name: "Neon", atomicMass: "20.180", electronConfiguration: "[He] 2s² 2p⁶", group: 18, period: 2, category: "Edelgas", xpos: 18, ypos: 2 },
  // Period 3
  { atomicNumber: 11, symbol: "Na", name: "Natrium", atomicMass: "22.990", electronConfiguration: "[Ne] 3s¹", group: 1, period: 3, category: "Alkalimetall", xpos: 1, ypos: 3 },
  { atomicNumber: 12, symbol: "Mg", name: "Magnesium", atomicMass: "24.305", electronConfiguration: "[Ne] 3s²", group: 2, period: 3, category: "Erdalkalimetall", xpos: 2, ypos: 3 },
  { atomicNumber: 13, symbol: "Al", name: "Aluminium", atomicMass: "26.982", electronConfiguration: "[Ne] 3s² 3p¹", group: 13, period: 3, category: "Metall", xpos: 13, ypos: 3 },
  { atomicNumber: 14, symbol: "Si", name: "Silicium", atomicMass: "28.085", electronConfiguration: "[Ne] 3s² 3p²", group: 14, period: 3, category: "Halbmetall", xpos: 14, ypos: 3 },
  { atomicNumber: 15, symbol: "P", name: "Phosphor", atomicMass: "30.974", electronConfiguration: "[Ne] 3s² 3p³", group: 15, period: 3, category: "Nichtmetall", xpos: 15, ypos: 3 },
  { atomicNumber: 16, symbol: "S", name: "Schwefel", atomicMass: "32.06", electronConfiguration: "[Ne] 3s² 3p⁴", group: 16, period: 3, category: "Nichtmetall", xpos: 16, ypos: 3 },
  { atomicNumber: 17, symbol: "Cl", name: "Chlor", atomicMass: "35.45", electronConfiguration: "[Ne] 3s² 3p⁵", group: 17, period: 3, category: "Halogen", xpos: 17, ypos: 3 },
  { atomicNumber: 18, symbol: "Ar", name: "Argon", atomicMass: "39.948", electronConfiguration: "[Ne] 3s² 3p⁶", group: 18, period: 3, category: "Edelgas", xpos: 18, ypos: 3 },
  // Period 4
  { atomicNumber: 19, symbol: "K", name: "Kalium", atomicMass: "39.098", electronConfiguration: "[Ar] 4s¹", group: 1, period: 4, category: "Alkalimetall", xpos: 1, ypos: 4 },
  { atomicNumber: 20, symbol: "Ca", name: "Calcium", atomicMass: "40.078", electronConfiguration: "[Ar] 4s²", group: 2, period: 4, category: "Erdalkalimetall", xpos: 2, ypos: 4 },
  { atomicNumber: 21, symbol: "Sc", name: "Scandium", atomicMass: "44.956", electronConfiguration: "[Ar] 3d¹ 4s²", group: 3, period: 4, category: "Übergangsmetall", xpos: 3, ypos: 4 },
  { atomicNumber: 22, symbol: "Ti", name: "Titan", atomicMass: "47.867", electronConfiguration: "[Ar] 3d² 4s²", group: 4, period: 4, category: "Übergangsmetall", xpos: 4, ypos: 4 },
  { atomicNumber: 23, symbol: "V", name: "Vanadium", atomicMass: "50.942", electronConfiguration: "[Ar] 3d³ 4s²", group: 5, period: 4, category: "Übergangsmetall", xpos: 5, ypos: 4 },
  { atomicNumber: 24, symbol: "Cr", name: "Chrom", atomicMass: "51.996", electronConfiguration: "[Ar] 3d⁵ 4s¹", group: 6, period: 4, category: "Übergangsmetall", xpos: 6, ypos: 4 },
  { atomicNumber: 25, symbol: "Mn", name: "Mangan", atomicMass: "54.938", electronConfiguration: "[Ar] 3d⁵ 4s²", group: 7, period: 4, category: "Übergangsmetall", xpos: 7, ypos: 4 },
  { atomicNumber: 26, symbol: "Fe", name: "Eisen", atomicMass: "55.845", electronConfiguration: "[Ar] 3d⁶ 4s²", group: 8, period: 4, category: "Übergangsmetall", xpos: 8, ypos: 4 },
  { atomicNumber: 27, symbol: "Co", name: "Cobalt", atomicMass: "58.933", electronConfiguration: "[Ar] 3d⁷ 4s²", group: 9, period: 4, category: "Übergangsmetall", xpos: 9, ypos: 4 },
  { atomicNumber: 28, symbol: "Ni", name: "Nickel", atomicMass: "58.693", electronConfiguration: "[Ar] 3d⁸ 4s²", group: 10, period: 4, category: "Übergangsmetall", xpos: 10, ypos: 4 },
  { atomicNumber: 29, symbol: "Cu", name: "Kupfer", atomicMass: "63.546", electronConfiguration: "[Ar] 3d¹⁰ 4s¹", group: 11, period: 4, category: "Übergangsmetall", xpos: 11, ypos: 4 },
  { atomicNumber: 30, symbol: "Zn", name: "Zink", atomicMass: "65.38", electronConfiguration: "[Ar] 3d¹⁰ 4s²", group: 12, period: 4, category: "Übergangsmetall", xpos: 12, ypos: 4 },
  { atomicNumber: 31, symbol: "Ga", name: "Gallium", atomicMass: "69.723", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p¹", group: 13, period: 4, category: "Metall", xpos: 13, ypos: 4 },
  { atomicNumber: 32, symbol: "Ge", name: "Germanium", atomicMass: "72.630", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p²", group: 14, period: 4, category: "Halbmetall", xpos: 14, ypos: 4 },
  { atomicNumber: 33, symbol: "As", name: "Arsen", atomicMass: "74.922", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p³", group: 15, period: 4, category: "Halbmetall", xpos: 15, ypos: 4 },
  { atomicNumber: 34, symbol: "Se", name: "Selen", atomicMass: "78.971", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p⁴", group: 16, period: 4, category: "Nichtmetall", xpos: 16, ypos: 4 },
  { atomicNumber: 35, symbol: "Br", name: "Brom", atomicMass: "79.904", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p⁵", group: 17, period: 4, category: "Halogen", xpos: 17, ypos: 4 },
  { atomicNumber: 36, symbol: "Kr", name: "Krypton", atomicMass: "83.798", electronConfiguration: "[Ar] 3d¹⁰ 4s² 4p⁶", group: 18, period: 4, category: "Edelgas", xpos: 18, ypos: 4 },
  // Period 5
  { atomicNumber: 37, symbol: "Rb", name: "Rubidium", atomicMass: "85.468", electronConfiguration: "[Kr] 5s¹", group: 1, period: 5, category: "Alkalimetall", xpos: 1, ypos: 5 },
  { atomicNumber: 38, symbol: "Sr", name: "Strontium", atomicMass: "87.62", electronConfiguration: "[Kr] 5s²", group: 2, period: 5, category: "Erdalkalimetall", xpos: 2, ypos: 5 },
  { atomicNumber: 39, symbol: "Y", name: "Yttrium", atomicMass: "88.906", electronConfiguration: "[Kr] 4d¹ 5s²", group: 3, period: 5, category: "Übergangsmetall", xpos: 3, ypos: 5 },
  { atomicNumber: 40, symbol: "Zr", name: "Zirconium", atomicMass: "91.224", electronConfiguration: "[Kr] 4d² 5s²", group: 4, period: 5, category: "Übergangsmetall", xpos: 4, ypos: 5 },
  { atomicNumber: 41, symbol: "Nb", name: "Niob", atomicMass: "92.906", electronConfiguration: "[Kr] 4d⁴ 5s¹", group: 5, period: 5, category: "Übergangsmetall", xpos: 5, ypos: 5 },
  { atomicNumber: 42, symbol: "Mo", name: "Molybdän", atomicMass: "95.96", electronConfiguration: "[Kr] 4d⁵ 5s¹", group: 6, period: 5, category: "Übergangsmetall", xpos: 6, ypos: 5 },
  { atomicNumber: 43, symbol: "Tc", name: "Technetium", atomicMass: "(98)", electronConfiguration: "[Kr] 4d⁵ 5s²", group: 7, period: 5, category: "Übergangsmetall", xpos: 7, ypos: 5 },
  { atomicNumber: 44, symbol: "Ru", name: "Ruthenium", atomicMass: "101.07", electronConfiguration: "[Kr] 4d⁷ 5s¹", group: 8, period: 5, category: "Übergangsmetall", xpos: 8, ypos: 5 },
  { atomicNumber: 45, symbol: "Rh", name: "Rhodium", atomicMass: "102.91", electronConfiguration: "[Kr] 4d⁸ 5s¹", group: 9, period: 5, category: "Übergangsmetall", xpos: 9, ypos: 5 },
  { atomicNumber: 46, symbol: "Pd", name: "Palladium", atomicMass: "106.42", electronConfiguration: "[Kr] 4d¹⁰", group: 10, period: 5, category: "Übergangsmetall", xpos: 10, ypos: 5 },
  { atomicNumber: 47, symbol: "Ag", name: "Silber", atomicMass: "107.87", electronConfiguration: "[Kr] 4d¹⁰ 5s¹", group: 11, period: 5, category: "Übergangsmetall", xpos: 11, ypos: 5 },
  { atomicNumber: 48, symbol: "Cd", name: "Cadmium", atomicMass: "112.41", electronConfiguration: "[Kr] 4d¹⁰ 5s²", group: 12, period: 5, category: "Übergangsmetall", xpos: 12, ypos: 5 },
  { atomicNumber: 49, symbol: "In", name: "Indium", atomicMass: "114.82", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p¹", group: 13, period: 5, category: "Metall", xpos: 13, ypos: 5 },
  { atomicNumber: 50, symbol: "Sn", name: "Zinn", atomicMass: "118.71", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p²", group: 14, period: 5, category: "Metall", xpos: 14, ypos: 5 },
  { atomicNumber: 51, symbol: "Sb", name: "Antimon", atomicMass: "121.76", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p³", group: 15, period: 5, category: "Halbmetall", xpos: 15, ypos: 5 },
  { atomicNumber: 52, symbol: "Te", name: "Tellur", atomicMass: "127.60", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p⁴", group: 16, period: 5, category: "Halbmetall", xpos: 16, ypos: 5 },
  { atomicNumber: 53, symbol: "I", name: "Iod", atomicMass: "126.90", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p⁵", group: 17, period: 5, category: "Halogen", xpos: 17, ypos: 5 },
  { atomicNumber: 54, symbol: "Xe", name: "Xenon", atomicMass: "131.29", electronConfiguration: "[Kr] 4d¹⁰ 5s² 5p⁶", group: 18, period: 5, category: "Edelgas", xpos: 18, ypos: 5 },
  // Period 6
  { atomicNumber: 55, symbol: "Cs", name: "Caesium", atomicMass: "132.91", electronConfiguration: "[Xe] 6s¹", group: 1, period: 6, category: "Alkalimetall", xpos: 1, ypos: 6 },
  { atomicNumber: 56, symbol: "Ba", name: "Barium", atomicMass: "137.33", electronConfiguration: "[Xe] 6s²", group: 2, period: 6, category: "Erdalkalimetall", xpos: 2, ypos: 6 },
  { atomicNumber: 57, symbol: "La", name: "Lanthan", atomicMass: "138.91", electronConfiguration: "[Xe] 5d¹ 6s²", group: 3, period: 6, category: "Lanthanoid", xpos: 3, ypos: 9 },
  { atomicNumber: 58, symbol: "Ce", name: "Cer", atomicMass: "140.12", electronConfiguration: "[Xe] 4f¹ 5d¹ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 4, ypos: 9 },
  { atomicNumber: 59, symbol: "Pr", name: "Praseodym", atomicMass: "140.91", electronConfiguration: "[Xe] 4f³ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 5, ypos: 9 },
  { atomicNumber: 60, symbol: "Nd", name: "Neodym", atomicMass: "144.24", electronConfiguration: "[Xe] 4f⁴ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 6, ypos: 9 },
  { atomicNumber: 61, symbol: "Pm", name: "Promethium", atomicMass: "(145)", electronConfiguration: "[Xe] 4f⁵ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 7, ypos: 9 },
  { atomicNumber: 62, symbol: "Sm", name: "Samarium", atomicMass: "150.36", electronConfiguration: "[Xe] 4f⁶ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 8, ypos: 9 },
  { atomicNumber: 63, symbol: "Eu", name: "Europium", atomicMass: "151.96", electronConfiguration: "[Xe] 4f⁷ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 9, ypos: 9 },
  { atomicNumber: 64, symbol: "Gd", name: "Gadolinium", atomicMass: "157.25", electronConfiguration: "[Xe] 4f⁷ 5d¹ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 10, ypos: 9 },
  { atomicNumber: 65, symbol: "Tb", name: "Terbium", atomicMass: "158.93", electronConfiguration: "[Xe] 4f⁹ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 11, ypos: 9 },
  { atomicNumber: 66, symbol: "Dy", name: "Dysprosium", atomicMass: "162.50", electronConfiguration: "[Xe] 4f¹⁰ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 12, ypos: 9 },
  { atomicNumber: 67, symbol: "Ho", name: "Holmium", atomicMass: "164.93", electronConfiguration: "[Xe] 4f¹¹ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 13, ypos: 9 },
  { atomicNumber: 68, symbol: "Er", name: "Erbium", atomicMass: "167.26", electronConfiguration: "[Xe] 4f¹² 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 14, ypos: 9 },
  { atomicNumber: 69, symbol: "Tm", name: "Thulium", atomicMass: "168.93", electronConfiguration: "[Xe] 4f¹³ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 15, ypos: 9 },
  { atomicNumber: 70, symbol: "Yb", name: "Ytterbium", atomicMass: "173.05", electronConfiguration: "[Xe] 4f¹⁴ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 16, ypos: 9 },
  { atomicNumber: 71, symbol: "Lu", name: "Lutetium", atomicMass: "174.97", electronConfiguration: "[Xe] 4f¹⁴ 5d¹ 6s²", group: null, period: 6, category: "Lanthanoid", xpos: 17, ypos: 9 }, // Group is sometimes 3 for Lu
  { atomicNumber: 72, symbol: "Hf", name: "Hafnium", atomicMass: "178.49", electronConfiguration: "[Xe] 4f¹⁴ 5d² 6s²", group: 4, period: 6, category: "Übergangsmetall", xpos: 4, ypos: 6 },
  { atomicNumber: 73, symbol: "Ta", name: "Tantal", atomicMass: "180.95", electronConfiguration: "[Xe] 4f¹⁴ 5d³ 6s²", group: 5, period: 6, category: "Übergangsmetall", xpos: 5, ypos: 6 },
  { atomicNumber: 74, symbol: "W", name: "Wolfram", atomicMass: "183.84", electronConfiguration: "[Xe] 4f¹⁴ 5d⁴ 6s²", group: 6, period: 6, category: "Übergangsmetall", xpos: 6, ypos: 6 },
  { atomicNumber: 75, symbol: "Re", name: "Rhenium", atomicMass: "186.21", electronConfiguration: "[Xe] 4f¹⁴ 5d⁵ 6s²", group: 7, period: 6, category: "Übergangsmetall", xpos: 7, ypos: 6 },
  { atomicNumber: 76, symbol: "Os", name: "Osmium", atomicMass: "190.23", electronConfiguration: "[Xe] 4f¹⁴ 5d⁶ 6s²", group: 8, period: 6, category: "Übergangsmetall", xpos: 8, ypos: 6 },
  { atomicNumber: 77, symbol: "Ir", name: "Iridium", atomicMass: "192.22", electronConfiguration: "[Xe] 4f¹⁴ 5d⁷ 6s²", group: 9, period: 6, category: "Übergangsmetall", xpos: 9, ypos: 6 },
  { atomicNumber: 78, symbol: "Pt", name: "Platin", atomicMass: "195.08", electronConfiguration: "[Xe] 4f¹⁴ 5d⁹ 6s¹", group: 10, period: 6, category: "Übergangsmetall", xpos: 10, ypos: 6 },
  { atomicNumber: 79, symbol: "Au", name: "Gold", atomicMass: "196.97", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s¹", group: 11, period: 6, category: "Übergangsmetall", xpos: 11, ypos: 6 },
  { atomicNumber: 80, symbol: "Hg", name: "Quecksilber", atomicMass: "200.59", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s²", group: 12, period: 6, category: "Übergangsmetall", xpos: 12, ypos: 6 },
  { atomicNumber: 81, symbol: "Tl", name: "Thallium", atomicMass: "204.38", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p¹", group: 13, period: 6, category: "Metall", xpos: 13, ypos: 6 },
  { atomicNumber: 82, symbol: "Pb", name: "Blei", atomicMass: "207.2", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²", group: 14, period: 6, category: "Metall", xpos: 14, ypos: 6 },
  { atomicNumber: 83, symbol: "Bi", name: "Bismut", atomicMass: "208.98", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p³", group: 15, period: 6, category: "Metall", xpos: 15, ypos: 6 },
  { atomicNumber: 84, symbol: "Po", name: "Polonium", atomicMass: "(209)", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁴", group: 16, period: 6, category: "Halbmetall", xpos: 16, ypos: 6 },
  { atomicNumber: 85, symbol: "At", name: "Astat", atomicMass: "(210)", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁵", group: 17, period: 6, category: "Halogen", xpos: 17, ypos: 6 }, 
  { atomicNumber: 86, symbol: "Rn", name: "Radon", atomicMass: "(222)", electronConfiguration: "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶", group: 18, period: 6, category: "Edelgas", xpos: 18, ypos: 6 },
  // Period 7
  { atomicNumber: 87, symbol: "Fr", name: "Francium", atomicMass: "(223)", electronConfiguration: "[Rn] 7s¹", group: 1, period: 7, category: "Alkalimetall", xpos: 1, ypos: 7 },
  { atomicNumber: 88, symbol: "Ra", name: "Radium", atomicMass: "(226)", electronConfiguration: "[Rn] 7s²", group: 2, period: 7, category: "Erdalkalimetall", xpos: 2, ypos: 7 },
  { atomicNumber: 89, symbol: "Ac", name: "Actinium", atomicMass: "(227)", electronConfiguration: "[Rn] 6d¹ 7s²", group: 3, period: 7, category: "Actinoid", xpos: 3, ypos: 10 },
  { atomicNumber: 90, symbol: "Th", name: "Thorium", atomicMass: "232.04", electronConfiguration: "[Rn] 6d² 7s²", group: null, period: 7, category: "Actinoid", xpos: 4, ypos: 10 },
  { atomicNumber: 91, symbol: "Pa", name: "Protactinium", atomicMass: "231.04", electronConfiguration: "[Rn] 5f² 6d¹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 5, ypos: 10 },
  { atomicNumber: 92, symbol: "U", name: "Uran", atomicMass: "238.03", electronConfiguration: "[Rn] 5f³ 6d¹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 6, ypos: 10 },
  { atomicNumber: 93, symbol: "Np", name: "Neptunium", atomicMass: "(237)", electronConfiguration: "[Rn] 5f⁴ 6d¹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 7, ypos: 10 },
  { atomicNumber: 94, symbol: "Pu", name: "Plutonium", atomicMass: "(244)", electronConfiguration: "[Rn] 5f⁶ 7s²", group: null, period: 7, category: "Actinoid", xpos: 8, ypos: 10 },
  { atomicNumber: 95, symbol: "Am", name: "Americium", atomicMass: "(243)", electronConfiguration: "[Rn] 5f⁷ 7s²", group: null, period: 7, category: "Actinoid", xpos: 9, ypos: 10 },
  { atomicNumber: 96, symbol: "Cm", name: "Curium", atomicMass: "(247)", electronConfiguration: "[Rn] 5f⁷ 6d¹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 10, ypos: 10 },
  { atomicNumber: 97, symbol: "Bk", name: "Berkelium", atomicMass: "(247)", electronConfiguration: "[Rn] 5f⁹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 11, ypos: 10 },
  { atomicNumber: 98, symbol: "Cf", name: "Californium", atomicMass: "(251)", electronConfiguration: "[Rn] 5f¹⁰ 7s²", group: null, period: 7, category: "Actinoid", xpos: 12, ypos: 10 },
  { atomicNumber: 99, symbol: "Es", name: "Einsteinium", atomicMass: "(252)", electronConfiguration: "[Rn] 5f¹¹ 7s²", group: null, period: 7, category: "Actinoid", xpos: 13, ypos: 10 },
  { atomicNumber: 100, symbol: "Fm", name: "Fermium", atomicMass: "(257)", electronConfiguration: "[Rn] 5f¹² 7s²", group: null, period: 7, category: "Actinoid", xpos: 14, ypos: 10 },
  { atomicNumber: 101, symbol: "Md", name: "Mendelevium", atomicMass: "(258)", electronConfiguration: "[Rn] 5f¹³ 7s²", group: null, period: 7, category: "Actinoid", xpos: 15, ypos: 10 },
  { atomicNumber: 102, symbol: "No", name: "Nobelium", atomicMass: "(259)", electronConfiguration: "[Rn] 5f¹⁴ 7s²", group: null, period: 7, category: "Actinoid", xpos: 16, ypos: 10 },
  { atomicNumber: 103, symbol: "Lr", name: "Lawrencium", atomicMass: "(262)", electronConfiguration: "[Rn] 5f¹⁴ 7s² 7p¹", group: null, period: 7, category: "Actinoid", xpos: 17, ypos: 10 }, // Group is sometimes 3 for Lr
  { atomicNumber: 104, symbol: "Rf", name: "Rutherfordium", atomicMass: "(267)", electronConfiguration: "[Rn] 5f¹⁴ 6d² 7s²", group: 4, period: 7, category: "Übergangsmetall", xpos: 4, ypos: 7 },
  { atomicNumber: 105, symbol: "Db", name: "Dubnium", atomicMass: "(270)", electronConfiguration: "[Rn] 5f¹⁴ 6d³ 7s²", group: 5, period: 7, category: "Übergangsmetall", xpos: 5, ypos: 7 },
  { atomicNumber: 106, symbol: "Sg", name: "Seaborgium", atomicMass: "(271)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁴ 7s²", group: 6, period: 7, category: "Übergangsmetall", xpos: 6, ypos: 7 },
  { atomicNumber: 107, symbol: "Bh", name: "Bohrium", atomicMass: "(270)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁵ 7s²", group: 7, period: 7, category: "Übergangsmetall", xpos: 7, ypos: 7 },
  { atomicNumber: 108, symbol: "Hs", name: "Hassium", atomicMass: "(277)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁶ 7s²", group: 8, period: 7, category: "Übergangsmetall", xpos: 8, ypos: 7 },
  { atomicNumber: 109, symbol: "Mt", name: "Meitnerium", atomicMass: "(278)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁷ 7s²", group: 9, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 9, ypos: 7 },
  { atomicNumber: 110, symbol: "Ds", name: "Darmstadtium", atomicMass: "(281)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁸ 7s²", group: 10, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 10, ypos: 7 }, 
  { atomicNumber: 111, symbol: "Rg", name: "Roentgenium", atomicMass: "(282)", electronConfiguration: "[Rn] 5f¹⁴ 6d⁹ 7s²", group: 11, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 11, ypos: 7 }, 
  { atomicNumber: 112, symbol: "Cn", name: "Copernicium", atomicMass: "(285)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s²", group: 12, period: 7, category: "Übergangsmetall", xpos: 12, ypos: 7 }, 
  { atomicNumber: 113, symbol: "Nh", name: "Nihonium", atomicMass: "(286)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p¹", group: 13, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 13, ypos: 7 },
  { atomicNumber: 114, symbol: "Fl", name: "Flerovium", atomicMass: "(289)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p²", group: 14, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 14, ypos: 7 },
  { atomicNumber: 115, symbol: "Mc", name: "Moscovium", atomicMass: "(290)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p³", group: 15, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 15, ypos: 7 },
  { atomicNumber: 116, symbol: "Lv", name: "Livermorium", atomicMass: "(293)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁴", group: 16, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 16, ypos: 7 },
  { atomicNumber: 117, symbol: "Ts", name: "Tenness", atomicMass: "(294)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁵", group: 17, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 17, ypos: 7 }, 
  { atomicNumber: 118, symbol: "Og", name: "Oganesson", atomicMass: "(294)", electronConfiguration: "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁶", group: 18, period: 7, category: "Unbekannte chemische Eigenschaften", xpos: 18, ypos: 7 }, 
];


export const MAX_ATOMIC_NUMBER = 118;
export const INITIAL_MAX_LEARNED_ATOMIC_NUMBER = 10;
export const LEARNING_CHUNK_SIZE = 10;

// For Comfort Level Progression
export const MIN_COMFORT_LEVEL_FOR_ADVANCEMENT: ComfortLevel = 2; // :| (Kann ich manchmal)
export const MIN_PROPORTION_HIGH_COMFORT_FOR_ADVANCEMENT = 0.5; // 50% must be :) (Kann ich)

export const LOCAL_STORAGE_SETTINGS_KEY = 'periodensystemAppSettings';
export const LOCAL_STORAGE_LEARNED_MAX_KEY = 'periodensystemLearnedMaxAtomicNumber';
export const LOCAL_STORAGE_COMFORT_LEVELS_KEY = 'periodensystemComfortLevels';
// LOCAL_STORAGE_QUIZ_HISTORY_KEY is removed

export const ALL_CATEGORIES = [
  "Alkalimetall", "Erdalkalimetall", "Lanthanoid", "Actinoid",
  "Übergangsmetall", "Metall", "Halbmetall", "Nichtmetall",
  "Halogen", "Edelgas", "Unbekannte chemische Eigenschaften"
];
// Removed "Unbekannt" if not used by any actual element. Ensure all elements have a category.

export const CATEGORY_COLORS: { [key: string]: { bg: string; text: string } } = {
  "Alkalimetall": { bg: "bg-red-500", text: "text-white" },
  "Erdalkalimetall": { bg: "bg-orange-500", text: "text-white" },
  "Lanthanoid": { bg: "bg-yellow-300", text: "text-slate-800" },
  "Actinoid": { bg: "bg-amber-500", text: "text-white" },
  "Übergangsmetall": { bg: "bg-yellow-500", text: "text-slate-800" },
  "Metall": { bg: "bg-sky-400", text: "text-slate-800" },
  "Halbmetall": { bg: "bg-teal-500", text: "text-white" },
  "Nichtmetall": { bg: "bg-green-500", text: "text-white" },
  "Halogen": { bg: "bg-indigo-500", text: "text-white" },
  "Edelgas": { bg: "bg-purple-500", text: "text-white" },
  "Unbekannte chemische Eigenschaften": { bg: "bg-slate-500", text: "text-white" },
  // Default/fallback, though ideally all elements have explicit categories
  "Unbekannt": { bg: "bg-gray-400", text: "text-slate-800" }, 
};

export const QUIZ_MODE_OPTIONS = [
  { value: QuizMode.SymbolFromNumber, label: "Symbol aus Ordnungszahl" },
  { value: QuizMode.SymbolFromName, label: "Symbol aus Name" },
  { value: QuizMode.NumberFromSymbol, label: "Ordnungszahl aus Symbol" },
  { value: QuizMode.NumberFromName, label: "Ordnungszahl aus Name" },
  { value: QuizMode.NameFromSymbol, label: "Name aus Symbol" },
  { value: QuizMode.NameFromNumber, label: "Name aus Ordnungszahl" },
  { value: QuizMode.Comprehensive, label: "Umfassend (1->2)" },
];

export const COMFORT_LEVELS: { level: ComfortLevel; label: string; emoji: string }[] = [
  { level: 1, label: "Kann ich noch nicht auswendig", emoji: "😟" },
  { level: 2, label: "Kann ich manchmal", emoji: "🤔" },
  { level: 3, label: "Kann ich!", emoji: "😊" },
];

export const DEFAULT_COMFORT_LEVEL: ComfortLevel = 1;
