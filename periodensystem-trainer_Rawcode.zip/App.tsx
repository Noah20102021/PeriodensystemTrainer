
import React, { useState, useEffect, useCallback } from 'react';
import { AppView, ElementData, QuizMode, Settings as AppSettings, ElementComfortLevels, ComfortLevel } from './types';
import { 
  ELEMENTS_DATA, 
  MAX_ATOMIC_NUMBER, 
  QUIZ_MODE_OPTIONS,
  INITIAL_MAX_LEARNED_ATOMIC_NUMBER,
  LEARNING_CHUNK_SIZE,
  LOCAL_STORAGE_LEARNED_MAX_KEY,
  LOCAL_STORAGE_SETTINGS_KEY,
  LOCAL_STORAGE_COMFORT_LEVELS_KEY,
  DEFAULT_COMFORT_LEVEL,
  MIN_COMFORT_LEVEL_FOR_ADVANCEMENT,
  MIN_PROPORTION_HIGH_COMFORT_FOR_ADVANCEMENT,
  COMFORT_LEVELS
} from './constants';
import PeriodicTable from './components/PeriodicTable';
import ElementDetailModal from './components/ElementDetailModal';
import QuizView from './components/QuizView';
import SettingsPanel from './components/SettingsPanel';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.Menu);
  const [selectedElement, setSelectedElement] = useState<ElementData | null>(null);
  
  const [currentLearnedMaxAtomicNumber, setCurrentLearnedMaxAtomicNumber] = useState<number>(() => {
    const savedMax = localStorage.getItem(LOCAL_STORAGE_LEARNED_MAX_KEY);
    return savedMax ? parseInt(savedMax, 10) : INITIAL_MAX_LEARNED_ATOMIC_NUMBER;
  });

  const [elementComfortLevels, setElementComfortLevels] = useState<ElementComfortLevels>(() => {
    const savedLevels = localStorage.getItem(LOCAL_STORAGE_COMFORT_LEVELS_KEY);
    try {
      return savedLevels ? JSON.parse(savedLevels) : {};
    } catch (e) {
      return {};
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
     const savedSettings = localStorage.getItem(LOCAL_STORAGE_SETTINGS_KEY);
     const defaultSettings: AppSettings = {
        atomicNumberRange: { min: 1, max: currentLearnedMaxAtomicNumber },
        selectedCategories: [],
        quizMode: QuizMode.SymbolFromNumber,
     };
     if (savedSettings) {
        try {
            const parsed = JSON.parse(savedSettings) as AppSettings;
            // Ensure max range from settings doesn't exceed current learned max initially
            parsed.atomicNumberRange.max = Math.min(parsed.atomicNumberRange.max, currentLearnedMaxAtomicNumber);
            return parsed;
        } catch (e) {
            return defaultSettings;
        }
     }
     return defaultSettings;
  });
  
  const [activeElements, setActiveElements] = useState<ElementData[]>([]);
  
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_LEARNED_MAX_KEY, currentLearnedMaxAtomicNumber.toString());
    setSettings(prevSettings => ({
      ...prevSettings,
      atomicNumberRange: {
        min: prevSettings.atomicNumberRange.min,
        // Max should be user-configurable up to their learned max
        max: Math.min(prevSettings.atomicNumberRange.max, currentLearnedMaxAtomicNumber)
      }
    }));
  }, [currentLearnedMaxAtomicNumber]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_COMFORT_LEVELS_KEY, JSON.stringify(elementComfortLevels));
  }, [elementComfortLevels]);

   useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  }, [settings]);


  const updateActiveElements = useCallback(() => {
    // Quiz elements should only go up to currentLearnedMaxAtomicNumber
    // but respect user's narrower min/max settings if they chose to focus
    const effectiveMaxAtomicNumber = Math.min(settings.atomicNumberRange.max, currentLearnedMaxAtomicNumber);
    const effectiveMinAtomicNumber = settings.atomicNumberRange.min;

    const filtered = ELEMENTS_DATA.filter(el => 
      el.atomicNumber >= effectiveMinAtomicNumber &&
      el.atomicNumber <= effectiveMaxAtomicNumber &&
      (settings.selectedCategories.length === 0 || settings.selectedCategories.includes(el.category))
    );
    setActiveElements(filtered);
  }, [settings, currentLearnedMaxAtomicNumber]);

  useEffect(() => {
    updateActiveElements();
  }, [settings, currentLearnedMaxAtomicNumber, updateActiveElements]);

  const handleElementClick = (element: ElementData) => {
    setSelectedElement(element);
  };

  const handleCloseModal = () => {
    setSelectedElement(null);
  };

  const handleSettingsChange = (newSettings: AppSettings) => {
    // Ensure max atomic number in settings does not exceed overall learned max
    const updatedSettings = {
      ...newSettings,
      atomicNumberRange: {
        ...newSettings.atomicNumberRange,
        max: Math.min(newSettings.atomicNumberRange.max, currentLearnedMaxAtomicNumber)
      }
    };
    setSettings(updatedSettings);
  };

  const handleQuizAttempt = useCallback((elementAtomicNumber: number, isCorrect: boolean, newComfortLevel?: ComfortLevel) => {
    setElementComfortLevels(prevLevels => {
      const updatedLevels = { ...prevLevels };
      if (isCorrect && newComfortLevel) {
        updatedLevels[elementAtomicNumber] = newComfortLevel;
      } else if (!isCorrect) {
        updatedLevels[elementAtomicNumber] = DEFAULT_COMFORT_LEVEL; // Reset to lowest on incorrect
      }
      return updatedLevels;
    });

    // Check for progression only if the answer was correct and for an element within the current learning chunk
    if (isCorrect && elementAtomicNumber <= currentLearnedMaxAtomicNumber && currentLearnedMaxAtomicNumber < MAX_ATOMIC_NUMBER) {
      // Use a timeout to ensure state update for elementComfortLevels is processed
      setTimeout(() => {
        setElementComfortLevels(currentLevels => {
          const elementsInCurrentChunk = ELEMENTS_DATA.filter(el => el.atomicNumber <= currentLearnedMaxAtomicNumber);
          if (elementsInCurrentChunk.length === 0) return currentLevels;

          let allMinComfortMet = true;
          let highComfortCount = 0;

          for (const el of elementsInCurrentChunk) {
            const comfort = currentLevels[el.atomicNumber] || DEFAULT_COMFORT_LEVEL;
            if (comfort < MIN_COMFORT_LEVEL_FOR_ADVANCEMENT) {
              allMinComfortMet = false;
              break;
            }
            if (comfort === 3) { // Max comfort level
              highComfortCount++;
            }
          }
          
          const proportionHighComfort = elementsInCurrentChunk.length > 0 ? highComfortCount / elementsInCurrentChunk.length : 0;

          if (allMinComfortMet && proportionHighComfort >= MIN_PROPORTION_HIGH_COMFORT_FOR_ADVANCEMENT) {
            const newMax = Math.min(currentLearnedMaxAtomicNumber + LEARNING_CHUNK_SIZE, MAX_ATOMIC_NUMBER);
            if (newMax > currentLearnedMaxAtomicNumber) {
              setCurrentLearnedMaxAtomicNumber(newMax);
              alert(`🎉 Super! Du hast die Elemente bis ${newMax} freigeschaltet! Dein Lernbereich wurde auf Elemente 1-${newMax} erweitert.`);
              // Update settings to reflect new max, if user was at their previous max
              setSettings(prev => ({
                ...prev,
                atomicNumberRange: {
                  ...prev.atomicNumberRange,
                  max: newMax
                }
              }))
            }
          }
          return currentLevels; // return currentLevels as setElementComfortLevels expects a new state or updater fn
        });
      }, 0);
    }
  }, [currentLearnedMaxAtomicNumber]);


  const renderView = () => {
    switch (currentView) {
      case AppView.Menu:
        return (
          <div className="flex flex-col items-center justify-center min-h-screen p-4 space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold text-sky-400 mb-8 text-center">Periodensystem Trainer</h1>
            <p className="text-slate-300 text-center">Aktuell lernst du Elemente bis Ordnungszahl: <span className="font-bold text-sky-300">{currentLearnedMaxAtomicNumber}</span></p>
             <div className="grid grid-cols-1 gap-2 text-sm text-slate-400 w-full max-w-sm">
              <p className="text-center">Fortschrittsbedingungen (bis {currentLearnedMaxAtomicNumber}):</p>
              <ul className="list-disc list-inside text-left mx-auto">
                <li>Alle Elemente mind. 'Kann ich manchmal' ({COMFORT_LEVELS.find(c=>c.level===MIN_COMFORT_LEVEL_FOR_ADVANCEMENT)?.emoji})</li>
                <li>Min. {MIN_PROPORTION_HIGH_COMFORT_FOR_ADVANCEMENT * 100}% davon 'Kann ich!' ({COMFORT_LEVELS.find(c=>c.level===3)?.emoji})</li>
              </ul>
            </div>
            <button
              onClick={() => setCurrentView(AppView.InteractiveTable)}
              className="w-full max-w-sm bg-sky-600 hover:bg-sky-500 text-white font-semibold py-3 px-6 rounded-lg text-lg transition shadow-lg hover:shadow-xl"
            >
              Interaktives Periodensystem
            </button>
            <button
              onClick={() => setCurrentView(AppView.Quiz)}
              className="w-full max-w-sm bg-teal-600 hover:bg-teal-500 text-white font-semibold py-3 px-6 rounded-lg text-lg transition shadow-lg hover:shadow-xl"
            >
              Quiz Starten
            </button>
            <button
              onClick={() => setCurrentView(AppView.Settings)}
              className="w-full max-w-sm bg-slate-600 hover:bg-slate-500 text-white font-semibold py-3 px-6 rounded-lg text-lg transition shadow-lg hover:shadow-xl"
            >
              Einstellungen
            </button>
          </div>
        );
      case AppView.InteractiveTable:
        // For table view, allow showing all elements up to MAX_ATOMIC_NUMBER based on settings
        const tableElementsSettings = {
            ...settings, 
            atomicNumberRange: {
                min: settings.atomicNumberRange.min, // User's chosen min
                max: settings.atomicNumberRange.max // User's chosen max, can be > currentLearnedMaxAtomicNumber for exploration
            }
        };
        return <PeriodicTable onElementClick={handleElementClick} settings={tableElementsSettings} />;
      case AppView.Quiz:
        if (activeElements.length === 0) {
          return (
            <div className="text-center p-8">
              <p className="text-xl mb-4">Keine Elemente für das Quiz basierend auf aktuellen Einstellungen und Lernfortschritt verfügbar.</p>
              <p className="mb-2">Dein Lernbereich: 1-{currentLearnedMaxAtomicNumber}. Deine Quiz-Einstellungen: {settings.atomicNumberRange.min}-{settings.atomicNumberRange.max}, Kategorien: {settings.selectedCategories.join(', ') || 'Alle'}.</p>
              <p className="mb-4">Passe ggf. die Einstellungen an (z.B. Min/Max Ordnungszahl, Kategorien) oder lerne weiter, um mehr Elemente freizuschalten.</p>
              <button onClick={() => setCurrentView(AppView.Settings)} className="bg-sky-600 hover:bg-sky-500 text-white font-semibold py-2 px-4 rounded-lg transition">
                Zu den Einstellungen
              </button>
            </div>
          );
        }
        return <QuizView 
                  settings={settings} 
                  activeElements={activeElements} 
                  suggestionElements={ELEMENTS_DATA}
                  onQuizAttempt={handleQuizAttempt}
                  elementComfortLevels={elementComfortLevels}
                />;
      case AppView.Settings:
        return <SettingsPanel 
                  settings={settings} 
                  onSettingsChange={handleSettingsChange} 
                  currentLearnedMaxAtomicNumber={currentLearnedMaxAtomicNumber} 
               />;
      default:
        return <div className="text-center p-8 text-xl">Ansicht nicht gefunden.</div>;
    }
  };
  
  const getAppBarTitle = () => {
    switch (currentView) {
      case AppView.Menu: return "Menü";
      case AppView.InteractiveTable: return "Interaktives Periodensystem";
      case AppView.Quiz: 
        const modeLabel = QUIZ_MODE_OPTIONS.find(opt => opt.value === settings.quizMode)?.label || "Quiz";
        return `Quiz: ${modeLabel}`;
      case AppView.Settings: return "Einstellungen";
      default: return "Periodensystem Trainer";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 text-slate-100">
      {currentView !== AppView.Menu && (
         <header className="bg-slate-800 shadow-md p-4 sticky top-0 z-40">
          <div className="container mx-auto flex flex-wrap justify-between items-center gap-2">
            <h1 className="text-lg sm:text-xl md:text-2xl font-semibold text-sky-400 truncate max-w-[calc(100%-120px)] sm:max-w-[calc(100%-150px)]">{getAppBarTitle()}</h1>
            <button 
              onClick={() => setCurrentView(AppView.Menu)}
              className="bg-sky-600 hover:bg-sky-500 text-white font-semibold py-2 px-3 sm:px-4 rounded-lg text-xs sm:text-sm transition"
            >
              Hauptmenü
            </button>
          </div>
        </header>
      )}

      <main className={`flex-grow container mx-auto p-2 sm:p-4 md:p-6 ${currentView === AppView.Menu ? '' : 'mt-2 sm:mt-4'}`}>
        {renderView()}
      </main>

      {selectedElement && (
        <ElementDetailModal element={selectedElement} onClose={handleCloseModal} />
      )}
      
      {currentView !== AppView.Menu && (
        <footer className="bg-slate-800 text-center p-3 sm:p-4 text-xs sm:text-sm text-slate-400 mt-auto">
          <p>&copy; {new Date().getFullYear()} Periodensystem Trainer. Alle Rechte vorbehalten.</p>
        </footer>
      )}
    </div>
  );
};

export default App;
