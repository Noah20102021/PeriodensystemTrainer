
export interface ElementData {
  atomicNumber: number;
  symbol: string;
  name: string;
  atomicMass: string;
  electronConfiguration: string;
  group: number | null;
  period: number;
  category: string; // German category name
  xpos: number; // Grid column for periodic table display (1-indexed)
  ypos: number; // Grid row for periodic table display (1-indexed)
}

export enum AppView {
  Menu = "MENU",
  InteractiveTable = "INTERACTIVE_TABLE",
  Quiz = "QUIZ",
  Settings = "SETTINGS",
}

export enum QuizMode {
  SymbolFromNumber = "SYMBOL_FROM_NUMBER",
  SymbolFromName = "SYMBOL_FROM_NAME",
  NumberFromSymbol = "NUMBER_FROM_SYMBOL",
  NumberFromName = "NUMBER_FROM_NAME",
  NameFromSymbol = "NAME_FROM_SYMBOL",
  NameFromNumber = "NAME_FROM_NUMBER",
  Comprehensive = "COMPREHENSIVE", // Given one, guess two
}

export interface QuizQuestion {
  element: ElementData;
  mode: QuizMode;
  promptField: "atomicNumber" | "name" | "symbol";
  promptValue: string | number;
  expectedAnswers: {
    symbol?: string;
    name?: string;
    atomicNumber?: number;
  };
}

export interface Settings {
  atomicNumberRange: {
    min: number;
    max: number;
  };
  selectedCategories: string[];
  quizMode: QuizMode;
}

export type ComfortLevel = 1 | 2 | 3;

export interface ElementComfortLevels {
  [atomicNumber: number]: ComfortLevel;
}

export interface QuizFeedbackModalProps {
  isOpen: boolean;
  isCorrect: boolean;
  element: ElementData;
  currentComfortLevel?: ComfortLevel; // Current comfort for this element
  onClose: (newComfortLevel?: ComfortLevel) => void; // Pass new level on confirm
  // onComfortLevelChange is removed, handled by onClose
}
