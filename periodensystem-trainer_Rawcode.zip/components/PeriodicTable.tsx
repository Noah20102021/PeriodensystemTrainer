
import React from 'react';
import { ElementData, Settings as AppSettings } from '../types';
import { CATEGORY_COLORS, ELEMENTS_DATA } from '../constants';

interface PeriodicTableProps {
  onElementClick: (element: ElementData) => void;
  settings: AppSettings;
}

const PeriodicTable: React.FC<PeriodicTableProps> = ({ onElementClick, settings }) => {
  const maxXPos = Math.max(...ELEMENTS_DATA.map(el => el.xpos), 18);
  // Ensure enough rows for the table, including Lanthanides/Actinides if they exist.
  // Default to 7 rows for main table, 10 if Lanthanides/Actinides are present.
  const actualMaxYPos = ELEMENTS_DATA.length > 0 ? Math.max(...ELEMENTS_DATA.map(el => el.ypos)) : 7;
  const maxYPos = Math.max(actualMaxYPos, 7);


  const isElementActive = (element: ElementData) => {
    const inRange = element.atomicNumber >= settings.atomicNumberRange.min && element.atomicNumber <= settings.atomicNumberRange.max;
    const inCategory = settings.selectedCategories.length === 0 || settings.selectedCategories.includes(element.category);
    return inRange && inCategory;
  };
  
  return (
    <div className="p-1 sm:p-2 md:p-4 bg-slate-800 rounded-lg shadow-xl overflow-auto">
      <div
        className="grid gap-0.5 md:gap-1"
        style={{
          gridTemplateColumns: `repeat(${maxXPos}, minmax(0, 1fr))`,
          gridTemplateRows: `repeat(${maxYPos}, minmax(2.2rem, auto))`, // min height for cells
        }}
        aria-label="Periodensystem der Elemente"
      >
        {ELEMENTS_DATA.map((element) => {
          const isActive = isElementActive(element);
          const categoryStyle = CATEGORY_COLORS[element.category] || CATEGORY_COLORS["Unbekannt"];
          return (
            <button // Changed div to button for accessibility
              key={element.atomicNumber}
              className={`p-1 md:p-2 border border-slate-700 rounded flex flex-col items-center justify-center text-center cursor-pointer hover:ring-2 hover:ring-sky-400 focus:ring-2 focus:ring-sky-400 focus:outline-none transition-all duration-150 ${isActive ? categoryStyle.bg : 'bg-slate-600 opacity-50'} ${isActive ? categoryStyle.text : 'text-slate-400'}`}
              style={{
                gridColumnStart: element.xpos,
                gridRowStart: element.ypos,
                fontSize: 'clamp(0.5rem, 1.5vw, 0.75rem)', // Responsive font size slightly smaller
              }}
              onClick={() => onElementClick(element)}
              title={`${element.name} (${element.symbol})`}
              aria-label={`Element ${element.name}, Symbol ${element.symbol}, Ordnungszahl ${element.atomicNumber}`}
            >
              <div className="font-bold text-xs md:text-sm" aria-hidden="true">{element.symbol}</div>
              <div className="text-xxs md:text-xs" aria-hidden="true">{element.atomicNumber}</div>
              <div className="hidden sm:block text-xxs truncate w-full" aria-hidden="true">{element.name}</div>
            </button>
          );
        })}
        {/* Placeholder for Lanthanide/Actinide labels if needed */}
         { maxYPos >= 9 && ELEMENTS_DATA.some(el => el.ypos === 9 && isElementActive(el)) && (
          <div style={{ gridColumnStart: 2, gridRowStart: 9 }} className="flex items-center justify-center text-slate-400 text-xs pr-1" aria-hidden="true">
            Lanthanoide
          </div>
        )}
        { maxYPos >= 10 && ELEMENTS_DATA.some(el => el.ypos === 10 && isElementActive(el)) && (
          <div style={{ gridColumnStart: 2, gridRowStart: 10 }} className="flex items-center justify-center text-slate-400 text-xs pr-1" aria-hidden="true">
            Actinoide
          </div>
        )}
      </div>
    </div>
  );
};

export default PeriodicTable;
