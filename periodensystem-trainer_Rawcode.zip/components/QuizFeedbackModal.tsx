
import React, { useState, useEffect } from 'react';
import { ElementData, ComfortLevel, QuizFeedbackModalProps, QuizQuestion } from '../types';
import { CATEGORY_COLORS, COMFORT_LEVELS, DEFAULT_COMFORT_LEVEL } from '../constants';

const QuizFeedbackModal: React.FC<QuizFeedbackModalProps & { question: QuizQuestion | null }> = ({
  isOpen,
  isCorrect,
  element,
  question,
  currentComfortLevel,
  onClose,
}) => {
  const [selectedComfortLevel, setSelectedComfortLevel] = useState<ComfortLevel>(DEFAULT_COMFORT_LEVEL);

  useEffect(() => {
    if (isCorrect) {
      setSelectedComfortLevel(currentComfortLevel || DEFAULT_COMFORT_LEVEL);
    } else {
      setSelectedComfortLevel(DEFAULT_COMFORT_LEVEL); // Reset to default if incorrect
    }
  }, [isOpen, isCorrect, currentComfortLevel]);

  if (!isOpen) return null;

  const categoryStyle = CATEGORY_COLORS[element.category] || CATEGORY_COLORS["Unbekannt"];
  const feedbackColor = isCorrect ? 'bg-green-600' : 'bg-red-600';
  const feedbackEmoji = isCorrect ? '✅' : '❌';

  const handleConfirm = () => {
    onClose(isCorrect ? selectedComfortLevel : DEFAULT_COMFORT_LEVEL);
  };
  
  const getExpectedAnswersText = () => {
    if (!question) return null;
    const parts = [];
    if (question.expectedAnswers.symbol) parts.push(`Symbol: ${question.expectedAnswers.symbol}`);
    if (question.expectedAnswers.name) parts.push(`Name: ${question.expectedAnswers.name}`);
    if (question.expectedAnswers.atomicNumber) parts.push(`Ordnungszahl: ${question.expectedAnswers.atomicNumber}`);
    return parts.join(', ');
  };


  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
      <div className={`relative ${categoryStyle.bg} ${categoryStyle.text} p-6 md:p-8 rounded-xl shadow-2xl w-full max-w-lg transform transition-all duration-300 scale-100`}>
        <div className={`p-4 mb-6 rounded-lg text-center text-white ${feedbackColor}`}>
          <span className="text-2xl mr-2">{feedbackEmoji}</span>
          <h2 className="text-2xl font-bold inline">
            {isCorrect ? 'Richtig!' : 'Leider Falsch.'}
          </h2>
        </div>

        {!isCorrect && question && (
          <div className="mb-4 p-3 bg-slate-700 bg-opacity-50 rounded text-center">
            <p className="font-semibold">Du wurdest gefragt nach:</p>
            {question.promptField === "atomicNumber" && <p>Ordnungszahl: {question.promptValue}</p>}
            {question.promptField === "name" && <p>Elementname: {question.promptValue}</p>}
            {question.promptField === "symbol" && <p>Elementsymbol: {question.promptValue}</p>}
            <p className="mt-1 font-semibold">Die richtige(n) Antwort(en) für {element.name} ({element.symbol}) wäre(n) gewesen:</p>
            <p>{getExpectedAnswersText()}</p>
          </div>
        )}

        <div className="text-center mb-4">
          <h3 className="text-2xl font-bold">{element.name} ({element.symbol})</h3>
          <p className="text-lg opacity-90">Ordnungszahl: {element.atomicNumber}</p>
        </div>

        <div className="space-y-1 text-sm mb-6 bg-slate-800 bg-opacity-30 p-4 rounded-md">
          <p><strong>Atommasse:</strong> {element.atomicMass}</p>
          <p><strong>Elektronenkonfiguration:</strong> {element.electronConfiguration}</p>
          <p><strong>Gruppe:</strong> {element.group ?? 'N/A'}, <strong>Periode:</strong> {element.period}</p>
          <p><strong>Kategorie:</strong> {element.category}</p>
        </div>

        {isCorrect && (
          <div className="mb-6">
            <p className="font-semibold text-center mb-3">Wie gut kennst du dieses Element?</p>
            <div className="flex flex-col sm:flex-row justify-center space-y-2 sm:space-y-0 sm:space-x-2">
              {COMFORT_LEVELS.map(level => (
                <button
                  key={level.level}
                  onClick={() => setSelectedComfortLevel(level.level)}
                  className={`flex-1 p-3 rounded-lg border-2 transition-all duration-150
                               ${selectedComfortLevel === level.level ? 'bg-sky-500 border-sky-400 text-white ring-2 ring-sky-300' : `${categoryStyle.text} bg-slate-700 bg-opacity-40 border-slate-600 hover:bg-slate-600 hover:border-slate-500`}`}
                >
                  <span className="text-xl mr-2">{level.emoji}</span>
                  {level.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={handleConfirm}
          className="w-full bg-sky-600 hover:bg-sky-500 text-white font-semibold py-3 px-4 rounded-lg transition shadow-md"
        >
          {isCorrect ? 'Bestätigen & Nächste Frage' : 'Nächste Frage'}
        </button>
      </div>
    </div>
  );
};

export default QuizFeedbackModal;
