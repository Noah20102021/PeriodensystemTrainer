
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ElementData, QuizQuestion, QuizMode, Settings as AppSettings, ElementComfortLevels, ComfortLevel } from '../types';
import QuizFeedbackModal from './QuizFeedbackModal';
import { DEFAULT_COMFORT_LEVEL } from '../constants';

interface QuizViewProps {
  settings: AppSettings;
  activeElements: ElementData[];
  suggestionElements: ElementData[];
  onQuizAttempt: (elementAtomicNumber: number, isCorrect: boolean, newComfortLevel?: ComfortLevel) => void;
  elementComfortLevels: ElementComfortLevels;
}

const generateQuestion = (elements: ElementData[], mode: QuizMode): QuizQuestion | null => {
  if (elements.length === 0) return null;
  const randomElement = elements[Math.floor(Math.random() * elements.length)];
  
  let promptField: "atomicNumber" | "name" | "symbol";
  let promptValue: string | number;
  let expectedAnswers: QuizQuestion['expectedAnswers'] = {};

  switch (mode) {
    case QuizMode.SymbolFromNumber:
      promptField = "atomicNumber";
      promptValue = randomElement.atomicNumber;
      expectedAnswers = { symbol: randomElement.symbol };
      break;
    case QuizMode.SymbolFromName:
      promptField = "name";
      promptValue = randomElement.name;
      expectedAnswers = { symbol: randomElement.symbol };
      break;
    case QuizMode.NumberFromSymbol:
      promptField = "symbol";
      promptValue = randomElement.symbol;
      expectedAnswers = { atomicNumber: randomElement.atomicNumber };
      break;
    case QuizMode.NumberFromName:
      promptField = "name";
      promptValue = randomElement.name;
      expectedAnswers = { atomicNumber: randomElement.atomicNumber };
      break;
    case QuizMode.NameFromSymbol:
      promptField = "symbol";
      promptValue = randomElement.symbol;
      expectedAnswers = { name: randomElement.name };
      break;
    case QuizMode.NameFromNumber:
      promptField = "atomicNumber";
      promptValue = randomElement.atomicNumber;
      expectedAnswers = { name: randomElement.name };
      break;
    case QuizMode.Comprehensive:
      const fields: Array<"atomicNumber" | "name" | "symbol"> = ["atomicNumber", "name", "symbol"];
      promptField = fields[Math.floor(Math.random() * fields.length)];
      promptValue = randomElement[promptField];
      if (promptField !== "symbol") expectedAnswers.symbol = randomElement.symbol;
      if (promptField !== "name") expectedAnswers.name = randomElement.name;
      if (promptField !== "atomicNumber") expectedAnswers.atomicNumber = randomElement.atomicNumber;
      break;
    default: // Fallback, should ideally match one of the modes
      promptField = "name";
      promptValue = randomElement.name;
      expectedAnswers = { symbol: randomElement.symbol };
  }

  return { element: randomElement, mode, promptField, promptValue, expectedAnswers };
};


const QuizView: React.FC<QuizViewProps> = ({ settings, activeElements, suggestionElements, onQuizAttempt, elementComfortLevels }) => {
  const [currentQuestion, setCurrentQuestion] = useState<QuizQuestion | null>(null);
  const [userSymbol, setUserSymbol] = useState('');
  const [userName, setUserName] = useState('');
  const [userAtomicNumber, setUserAtomicNumber] = useState('');
  
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [lastAnswerCorrect, setLastAnswerCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState({ correct: 0, attempted: 0 });

  const [symbolSuggestions, setSymbolSuggestions] = useState<ElementData[]>([]);
  const [nameSuggestions, setNameSuggestions] = useState<ElementData[]>([]);
  const [showSymbolSuggestions, setShowSymbolSuggestions] = useState(false);
  const [showNameSuggestions, setShowNameSuggestions] = useState(false);

  const nameInputRef = useRef<HTMLInputElement>(null);
  const symbolInputRef = useRef<HTMLInputElement>(null);
  const suggestionsContainerRef = useRef<HTMLFormElement>(null);


  const loadNextQuestion = useCallback(() => {
    if (activeElements.length === 0) {
        setCurrentQuestion(null);
        return;
    }
    const newQuestion = generateQuestion(activeElements, settings.quizMode);
    setCurrentQuestion(newQuestion);
    setUserSymbol('');
    setUserName('');
    setUserAtomicNumber('');
    setIsFeedbackModalOpen(false); // Ensure modal is closed for new question
    setLastAnswerCorrect(null);
    setShowSymbolSuggestions(false);
    setShowNameSuggestions(false);
  }, [activeElements, settings.quizMode]);

  useEffect(() => {
    loadNextQuestion();
  }, [loadNextQuestion]); // initial load and when activeElements/settings change

 useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsContainerRef.current && !suggestionsContainerRef.current.contains(event.target as Node) &&
          nameInputRef.current && !nameInputRef.current.contains(event.target as Node) &&
          symbolInputRef.current && !symbolInputRef.current.contains(event.target as Node)) {
        setShowNameSuggestions(false);
        setShowSymbolSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);


  const handleNameInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUserName(value);
    if (value.trim()) {
      const filtered = suggestionElements.filter(el => 
        el.name.toLowerCase().includes(value.toLowerCase().trim())
      ).slice(0, 5); // Show top 5 suggestions
      setNameSuggestions(filtered);
      setShowNameSuggestions(filtered.length > 0);
    } else {
      setShowNameSuggestions(false);
    }
  };

  const handleSymbolInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUserSymbol(value);
    if (value.trim()) {
      const filtered = suggestionElements.filter(el => 
        el.symbol.toLowerCase().startsWith(value.toLowerCase().trim()) // startsWith for symbols
      ).slice(0, 5);
      setSymbolSuggestions(filtered);
      setShowSymbolSuggestions(filtered.length > 0);
    } else {
      setShowSymbolSuggestions(false);
    }
  };

  const selectNameSuggestion = (element: ElementData) => {
    setUserName(element.name);
    setShowNameSuggestions(false);
    nameInputRef.current?.focus();
  };

  const selectSymbolSuggestion = (element: ElementData) => {
    setUserSymbol(element.symbol);
    setShowSymbolSuggestions(false);
    symbolInputRef.current?.focus();
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentQuestion) return;

    let correct = true;
    const expected = currentQuestion.expectedAnswers;
    
    if (expected.symbol !== undefined && userSymbol.trim().toLowerCase() !== expected.symbol.toLowerCase()) {
      correct = false;
    }
    if (expected.name !== undefined && userName.trim().toLowerCase() !== expected.name.toLowerCase()) {
      correct = false;
    }
    if (expected.atomicNumber !== undefined && parseInt(userAtomicNumber, 10) !== expected.atomicNumber) {
      correct = false;
    }

    setLastAnswerCorrect(correct);
    setScore(prev => ({ correct: prev.correct + (correct ? 1 : 0), attempted: prev.attempted + 1 }));
    setIsFeedbackModalOpen(true);
    setShowSymbolSuggestions(false);
    setShowNameSuggestions(false);
  };

  const handleFeedbackModalClose = (newComfortLevel?: ComfortLevel) => {
    if (currentQuestion && lastAnswerCorrect !== null) {
      onQuizAttempt(currentQuestion.element.atomicNumber, lastAnswerCorrect, newComfortLevel);
    }
    setIsFeedbackModalOpen(false);
    loadNextQuestion();
  };
  
  if (!currentQuestion) {
    return <div className="text-center p-8 text-xl">Keine Elemente für das Quiz ausgewählt oder Quiz-Modus nicht definiert. Bitte Einstellungen überprüfen oder Lernfortschritt erweitern.</div>;
  }

  const getPromptText = () => {
    switch (currentQuestion.promptField) {
      case "atomicNumber": return `Ordnungszahl: ${currentQuestion.promptValue}`;
      case "name": return `Elementname: ${currentQuestion.promptValue}`;
      case "symbol": return `Elementsymbol: ${currentQuestion.promptValue}`;
    }
  };

  const currentElementComfort = elementComfortLevels[currentQuestion.element.atomicNumber] || DEFAULT_COMFORT_LEVEL;

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto bg-slate-800 rounded-lg shadow-xl">
      <h2 className="text-2xl font-bold text-sky-400 mb-6 text-center">Quiz-Modus</h2>
      <div className="mb-6 p-4 bg-slate-700 rounded-lg">
        <p className="text-lg text-center">Frage: <span className="font-semibold">{getPromptText()}</span></p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6" ref={suggestionsContainerRef}>
        {currentQuestion.expectedAnswers.symbol !== undefined && (
          <div className="relative">
            <label htmlFor="userSymbol" className="block text-sm font-medium text-slate-300 mb-1">Elementsymbol:</label>
            <input
              ref={symbolInputRef}
              type="text"
              id="userSymbol"
              value={userSymbol}
              onChange={handleSymbolInputChange}
              onFocus={() => userSymbol.trim() && symbolSuggestions.length > 0 && setShowSymbolSuggestions(true)}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
              autoComplete="off"
            />
            {showSymbolSuggestions && symbolSuggestions.length > 0 && (
              <div className="absolute z-20 w-full mt-1 bg-slate-600 border border-slate-500 rounded-md shadow-lg max-h-40 overflow-y-auto">
                {symbolSuggestions.map(el => (
                  <div 
                    key={el.symbol + el.atomicNumber} // Use a more unique key
                    className="p-2 hover:bg-sky-500 cursor-pointer"
                    onMouseDown={() => selectSymbolSuggestion(el)}
                  >
                    {el.symbol} ({el.name})
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {currentQuestion.expectedAnswers.name !== undefined && (
          <div className="relative">
            <label htmlFor="userName" className="block text-sm font-medium text-slate-300 mb-1">Elementname:</label>
            <input
              ref={nameInputRef}
              type="text"
              id="userName"
              value={userName}
              onChange={handleNameInputChange}
              onFocus={() => userName.trim() && nameSuggestions.length > 0 && setShowNameSuggestions(true)}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
              autoComplete="off"
            />
            {showNameSuggestions && nameSuggestions.length > 0 && (
              <div className="absolute z-20 w-full mt-1 bg-slate-600 border border-slate-500 rounded-md shadow-lg max-h-40 overflow-y-auto">
                {nameSuggestions.map(el => (
                  <div 
                    key={el.name + el.atomicNumber} // Use a more unique key
                    className="p-2 hover:bg-sky-500 cursor-pointer"
                    onMouseDown={() => selectNameSuggestion(el)}
                  >
                    {el.name} ({el.symbol})
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {currentQuestion.expectedAnswers.atomicNumber !== undefined && (
          <div>
            <label htmlFor="userAtomicNumber" className="block text-sm font-medium text-slate-300 mb-1">Ordnungszahl:</label>
            <input
              type="number"
              id="userAtomicNumber"
              value={userAtomicNumber}
              onChange={(e) => setUserAtomicNumber(e.target.value)}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
            />
          </div>
        )}
        
        <button type="submit" className="w-full bg-sky-600 hover:bg-sky-500 text-white font-semibold py-3 px-4 rounded-lg transition">
          Antwort überprüfen
        </button>
      </form>

      {isFeedbackModalOpen && currentQuestion && lastAnswerCorrect !== null && (
        <QuizFeedbackModal
          isOpen={isFeedbackModalOpen}
          isCorrect={lastAnswerCorrect}
          element={currentQuestion.element}
          question={currentQuestion}
          currentComfortLevel={currentElementComfort}
          onClose={handleFeedbackModalClose}
        />
      )}

      <div className="mt-8 text-center text-slate-300">
        <p>Punktestand: {score.correct} / {score.attempted}</p>
        {score.attempted > 0 && (
          <p>Erfolgsquote: {((score.correct / score.attempted) * 100).toFixed(1)}%</p>
        )}
      </div>
    </div>
  );
};

export default QuizView;
