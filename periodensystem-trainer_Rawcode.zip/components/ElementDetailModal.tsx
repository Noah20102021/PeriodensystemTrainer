
import React from 'react';
import { ElementData } from '../types';
import { CATEGORY_COLORS } from '../constants';

interface ElementDetailModalProps {
  element: ElementData | null;
  onClose: () => void;
}

const ElementDetailModal: React.FC<ElementDetailModalProps> = ({ element, onClose }) => {
  if (!element) return null;

  const categoryStyle = CATEGORY_COLORS[element.category] || CATEGORY_COLORS["Unbekannt"];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50 transition-opacity duration-300">
      <div className={`relative ${categoryStyle.bg} ${categoryStyle.text} p-6 md:p-8 rounded-xl shadow-2xl w-full max-w-md transform transition-all duration-300 scale-100`}>
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-2xl font-bold hover:opacity-75 transition-opacity"
          aria-label="Schließen"
        >
          &times;
        </button>
        <div className="text-center mb-6">
          <h2 className="text-3xl md:text-4xl font-bold">{element.name} ({element.symbol})</h2>
          <p className="text-xl md:text-2xl opacity-90">{element.atomicNumber}</p>
        </div>
        <div className="space-y-3 text-sm md:text-base">
          <p><strong className="font-semibold">Elementsymbol:</strong> {element.symbol}</p>
          <p><strong className="font-semibold">Ordnungszahl:</strong> {element.atomicNumber}</p>
          <p><strong className="font-semibold">Elementname:</strong> {element.name}</p>
          <p><strong className="font-semibold">Atommasse:</strong> {element.atomicMass}</p>
          <p><strong className="font-semibold">Elektronenkonfiguration:</strong> {element.electronConfiguration}</p>
          <p><strong className="font-semibold">Gruppe:</strong> {element.group ?? 'N/A'}</p>
          <p><strong className="font-semibold">Periode:</strong> {element.period}</p>
          <p><strong className="font-semibold">Kategorie:</strong> {element.category}</p>
        </div>
        <button
            onClick={onClose}
            className="mt-6 w-full bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-150"
          >
            Schließen
          </button>
      </div>
    </div>
  );
};

export default ElementDetailModal;
