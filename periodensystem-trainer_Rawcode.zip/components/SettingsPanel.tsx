
import React from 'react';
import { Settings, QuizMode } from '../types';
import { ALL_CATEGORIES, QUIZ_MODE_OPTIONS, MAX_ATOMIC_NUMBER } from '../constants';

interface SettingsPanelProps {
  settings: Settings;
  onSettingsChange: (newSettings: Settings) => void;
  currentLearnedMaxAtomicNumber: number;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSettingsChange, currentLearnedMaxAtomicNumber }) => {
  const handleRangeChange = (field: 'min' | 'max', value: string) => {
    const numValue = parseInt(value, 10);
    if (isNaN(numValue)) return;

    let newMin = settings.atomicNumberRange.min;
    let newMax = settings.atomicNumberRange.max;

    if (field === 'min') {
      newMin = Math.max(1, Math.min(numValue, settings.atomicNumberRange.max));
    } else { // 'max'
      newMax = Math.min(MAX_ATOMIC_NUMBER, Math.max(numValue, settings.atomicNumberRange.min));
    }
    onSettingsChange({ ...settings, atomicNumberRange: { min: newMin, max: newMax } });
  };

  const handleCategoryToggle = (category: string) => {
    const newCategories = settings.selectedCategories.includes(category)
      ? settings.selectedCategories.filter(c => c !== category)
      : [...settings.selectedCategories, category];
    onSettingsChange({ ...settings, selectedCategories: newCategories });
  };

  const handleQuizModeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onSettingsChange({ ...settings, quizMode: e.target.value as QuizMode });
  };

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto bg-slate-800 rounded-lg shadow-xl space-y-8">
      <h2 className="text-2xl font-bold text-sky-400 mb-6 text-center">Einstellungen</h2>

      <div>
        <h3 className="text-lg font-semibold text-slate-200 mb-2">Quiz-Modus Auswahl</h3>
        <select
            value={settings.quizMode}
            onChange={handleQuizModeChange}
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
          >
            {QUIZ_MODE_OPTIONS.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-200 mb-1">Ordnungszahl Bereich</h3>
        <p className="text-xs text-slate-400 mb-3">
            Dein aktueller Lernfortschritt umfasst Elemente bis Ordnungszahl {currentLearnedMaxAtomicNumber}. Du kannst diesen Bereich hier manuell anpassen.
        </p>
        <div className="flex items-center space-x-4">
          <div className="flex-1">
            <label htmlFor="minAtomicNumber" className="block text-sm font-medium text-slate-300 mb-1">Min:</label>
            <input
              type="number"
              id="minAtomicNumber"
              value={settings.atomicNumberRange.min}
              onChange={(e) => handleRangeChange('min', e.target.value)}
              min="1"
              max={MAX_ATOMIC_NUMBER}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
            />
          </div>
          <div className="flex-1">
            <label htmlFor="maxAtomicNumber" className="block text-sm font-medium text-slate-300 mb-1">Max:</label>
            <input
              type="number"
              id="maxAtomicNumber"
              value={settings.atomicNumberRange.max}
              onChange={(e) => handleRangeChange('max', e.target.value)}
              min="1"
              max={MAX_ATOMIC_NUMBER}
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-sky-500 focus:border-sky-500 transition"
            />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-slate-200 mb-3">Elementkategorien auswählen</h3>
        <p className="text-sm text-slate-400 mb-3">Wenn keine Kategorien ausgewählt sind, werden alle Elemente im gewählten Ordnungszahlbereich verwendet.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {ALL_CATEGORIES.map(category => (
            <label key={category} className="flex items-center space-x-2 p-3 bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-600 transition">
              <input
                type="checkbox"
                checked={settings.selectedCategories.includes(category)}
                onChange={() => handleCategoryToggle(category)}
                className="form-checkbox h-5 w-5 text-sky-500 bg-slate-600 border-slate-500 rounded focus:ring-sky-600"
              />
              <span className="text-slate-200 text-sm">{category}</span>
            </label>
          ))}
        </div>
      </div>
      <p className="text-xs text-slate-500 text-center mt-6">Änderungen werden sofort wirksam.</p>
    </div>
  );
};

export default SettingsPanel;
